window.Config = {
    API_URL: 'https://localhost:7056/api',
  };
  