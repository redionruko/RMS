function toggleSidebar() {
  const sidebar = document.getElementById('sidebar');
  const content = document.querySelector('.content');
  
  sidebar.classList.toggle('active');
  content.classList.toggle('sidebar-active');
}

